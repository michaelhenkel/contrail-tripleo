# vi: set ft=changelog :

2015-07-09 - 1.0.0
  * features:
    First release
